package org.example.keephealthy02.Mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.example.keephealthy02.Entity.Menu;

@Mapper
public interface MenuMapper extends BaseMapper<Menu> {
}
