package org.example.keephealthy02.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.example.keephealthy02.Entity.Sleep;

@Mapper
public interface SleepMapper extends BaseMapper<Sleep> {
}