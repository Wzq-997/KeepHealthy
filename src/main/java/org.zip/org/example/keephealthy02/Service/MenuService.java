package org.example.keephealthy02.Service;

import org.example.keephealthy02.Entity.Menu;

import java.util.List;

public interface MenuService {
//    获取所有的食谱
    List<Menu> getAll();
}
